import java.util.Scanner;
import java.util.Random;
import java.util.Locale;

public class lab2 {
    public static void main(String[] args) {

        rownanie();

} // end of main
public static double Input() {
    Scanner input = new Scanner(System.in);
    System.out.println("Podaj n: ");
    double n = input.nextDouble();
    return n;

}
public static void Zadanie1() {
        double ilStud = Input();
        double pkt, suma = 0;
        int a = 0, b = 40, ile = 0;

        if(ilStud > 0) {
            while(ilStud > 0) {
                System.out.println("Podaj lp. pkt 0 - 40");
                pkt = Input();
                if(pkt >= a && pkt <= b) {
                    suma += pkt;
                    ile++;
                    ilStud--;
                }
            } // end of while
            System.out.println("Ile: " + ile);
            System.out.println("Suma pkt: " + suma);
            System.out.println("Srednia = " + suma/ile);
        } else System.out.println("Grupa musi liczyc co najmniej 1 studenta");
}
public static void Zadanie2() {
        double sumad = 0, sumau = 0, iled = 0, ileu = 0, liczba;
    for (int i = 0; i < 10; i++) {
        System.out.println("Podaj liczbe " + ++i);
        liczba = Input();
        if(liczba > 0) {
            iled++;
            sumad += liczba;
        } else {
            ileu++;
            sumau += liczba;
        }
    } // end of for
    System.out.println("Ilosc liczb dodatnich: " + iled);
    System.out.println("Suma liczb dodatnich: " + sumad);
    System.out.println("Ilosc liczb ujemnych: " + ileu);
    System.out.println("Suma liczb ujemnych: " + sumau);
}
public static void Zadanie3() {
        double n = Input();
        double liczba, suma = 0;

        if(n > 0) {
            while(n > 0) {
                liczba = Input();
                if (liczba % 2 == 0) {
                    suma += liczba;
                }
                n--;
            }
        }else System.out.println("Ciag musi miec co najmniej jedna liczbe");
}
public static void Zadanie4() {
        double n = Input();
        int liczba, suma = 0;
        Random rand = new Random();


        if(n > 0) {
            while(n > 0) {
                liczba = rand.nextInt(56)-10; // -10-45
                if (liczba % 2 == 0) {
                    suma += liczba;
                }
                n--;
            }
            System.out.println("Suma liczb parzystych: " +suma);
        }else System.out.println("Ciag musi miec co najmniej jedna liczbe");
    }

    public static boolean czyPalindrom(String text) {
        int end = text.length() - 1;
        text = text.toLowerCase();

        for (int i = 0; i < text.length()/2; i++) {
            if(text.charAt(i) != text.charAt(end)) return false;
            end--;
        }
        return true;
    }

    public static void rownanie() {
        double a = Input();
        double b = Input();
        double c = Input();

        double delta, wynik1 = 0, wynik2 = 0, pdelta;

        delta = (b*b) - (4*a*c);
        pdelta = Math.sqrt(delta);
        if(delta>0) {
            wynik1 = (-b - pdelta) / (2 * a);
            wynik2 = (-b + pdelta) / (2 * a);
        }
        System.out.println("Wynik 1: " + wynik1 + " Wynik 2: " + wynik2);
    }


}// end of programm